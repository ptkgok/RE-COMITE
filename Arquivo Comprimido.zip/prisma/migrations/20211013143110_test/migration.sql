-- DropIndex
DROP INDEX "Rg_usuarioId_key";
