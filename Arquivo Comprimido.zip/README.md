# COMITE WITH NEXT JS and integrated BackEND (monolith)


# Database
- Prisma (access)
- postgres
    - user: patrick
    - pass: 87127186ab
    - db: sisrg
    - port: 5432
- docker