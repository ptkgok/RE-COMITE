export const SelectData = [
  {id: 1, value: "valor 1", label: "valor1" },
  {id: 2, value: "valor 2", label: "valor2" },
  {id: 3, value: "valor 3", label: "valor3" }
]

export const SelectDataBool = [
  {id: 1, value: true, label: "sim" },
  {id: 2, value: false, label: "não" },
]