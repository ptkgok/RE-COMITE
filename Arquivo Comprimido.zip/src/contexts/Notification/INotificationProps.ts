interface INotificationProps {
  ShowMessage: boolean
  setShowMessage: (value: boolean) => void
  Message: any
  setMessage: any
  Icon?: any
  setIcon?: any
}

export type { INotificationProps }
