import { getAPIClient } from "./axios";

export const api = getAPIClient()