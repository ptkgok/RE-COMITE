export const rolesOfUsers = [
  {
    id: 1,
    label: 'Administrador',
    value: 'ADMIN'
  },
  {
    id: 2,
    label: 'Usuario Comum',
    value: 'USUARIO'
  }
]
