interface INotificationProps {
  ShowMessage: any
  setShowMessage: any
  Message: any
  setMessage: any
  Icon?: any
  setIcon?: any
}

export type { INotificationProps }