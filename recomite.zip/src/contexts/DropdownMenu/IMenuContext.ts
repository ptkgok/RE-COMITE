interface IMenuContext {
  MenuActive?: string
  setMenuActive?: (data:string) => void
}

export type { IMenuContext }