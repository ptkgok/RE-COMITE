export const MotivosData = [
  { id: 1, value: "Auxilio Emergencial", label: "Auxilio Emergencial" },
  { id: 2, value: "Outros", label: "Outros" },
];

// export const StatusFake = [
//   { id: 1, titulo: 'REIMP. RET. SSA' },
//   { id: 2, titulo: 'REIMP. ENVIO CORREIO' },
//   { id: 3, titulo: 'AGENDAM P/ AT. PRESENCIAL' },
//   { id: 4, titulo: 'PENDENTE P/ AT. PRESENCIAL' },
//   { id: 5, titulo: 'LIGAR SAC P/ RETIRAR DOC' },
//   { id: 6, titulo: 'AG. ANALISE POSTERIOR' },
//   { id: 7, titulo: 'REIMP RETIRADA IIPM' }
// ]

export const PostosData = [
  { id: 1, value: "SAC COMERCIO", label: "SAC COMERCIO" },
  { id: 2, value: "SAC PERNAMBUES", label: "SAC PERNAMBUES" },
];

export const StatusData = [
  { id: 1, label: "Agendamento p/ interior" },
  { id: 2, label: "Agendamento Presencial" },
];
