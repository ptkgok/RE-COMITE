import React from "react";


const MyDoc: React.FC = () => {
  return (
    <div style={{ background: 'tomato' }}>
    </div>
  )
}

export default MyDoc;