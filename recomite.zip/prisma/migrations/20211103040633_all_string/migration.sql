-- AlterTable
ALTER TABLE "Certidao" ALTER COLUMN "data_de_nascimento" DROP NOT NULL,
ALTER COLUMN "data_de_solicitacao" DROP NOT NULL;
