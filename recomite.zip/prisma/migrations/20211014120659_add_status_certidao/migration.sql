-- DropIndex
DROP INDEX "Certidao_usuarioId_key";
