-- AlterTable
ALTER TABLE "Certidao" ALTER COLUMN "data_de_nascimento" SET DATA TYPE TEXT,
ALTER COLUMN "data_de_solicitacao" SET DATA TYPE TEXT;
